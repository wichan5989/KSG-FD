# Feedback Killer — v0.4 (restructured)

Same behaviour as v0.3 "DARK LAB", reorganised into clear layers. DSP algorithm and
parameters are unchanged.

## Layout
```
core/                      Platform-independent C++17 DSP (shared by desktop tests + Android)
  include/fk/              Config, Biquad, Fft, Engine, Math
  src/                     Engine.cpp, Biquad.cpp
tests/test.cpp             Desktop tests (tone, silence, bypass, reset, clamp)
android/app/src/main/
  cpp/jni_bridge.cpp       JNI glue; handle-based, no globals
  cpp/CMakeLists.txt       Builds feedback_jni, links ../core
  java/.../audio/NativeEngine.java    JNI wrapper
  java/.../audio/AudioPipeline.java   AudioRecord -> DSP -> AudioTrack thread
  java/.../ui/Theme.java, MainView.java   Dark console UI (no audio logic)
  java/.../MainActivity.java          Permissions + lifecycle + wiring
```

## v0.3 -> v0.4 mapping
| v0.3 | v0.4 |
|---|---|
| core/FeedbackEngine.{h,cpp} | core/include/fk/{Engine,Biquad,Fft,Config,Math}.h + core/src/ |
| native.cpp (global engine) | jni_bridge.cpp (Handle per NativeEngine) |
| MainActivity (UI + audio + JNI) | MainActivity + AudioPipeline + MainView + Theme + NativeEngine |

## Small fixes made while restructuring
- `bypass` is `std::atomic<bool>`; notch state is published to the UI via atomics (no data race).
- `nativeNotches` fills a caller-supplied array (no allocation on every UI poll).
- Start button now toggles to "STOP AUDIO TEST"; audio error messages are no longer instantly overwritten by "STOPPED".
- `Engine::reset()` no longer touches bypass (the app sets it explicitly).
- Android preset moved to `Config::androidLab()`.

## Build
- Desktop tests: `cmake -S . -B build && cmake --build build && ctest --test-dir build --output-on-failure`
- Android: open `android/` in Android Studio (SDK 35, NDK + CMake). Gradle wrapper not included.

## Limitations (unchanged from v0.3)
Lab use only: wired headphones at low volume, not for live PA. FFT runs on the audio thread,
Java AudioRecord/AudioTrack latency is not guaranteed, no USB routing / device selection,
sustained notes can be misclassified as feedback.
