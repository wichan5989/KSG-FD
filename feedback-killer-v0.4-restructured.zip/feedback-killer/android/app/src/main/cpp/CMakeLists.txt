cmake_minimum_required(VERSION 3.22)
project(feedback_jni LANGUAGES CXX)

# Single source of truth for the DSP: ../core (shared with desktop tests).
set(FK_ROOT ${CMAKE_CURRENT_SOURCE_DIR}/../../../../..)
add_subdirectory(${FK_ROOT}/core ${CMAKE_BINARY_DIR}/fk_core)

add_library(feedback_jni SHARED jni_bridge.cpp)
target_link_libraries(feedback_jni PRIVATE feedback_core log)
