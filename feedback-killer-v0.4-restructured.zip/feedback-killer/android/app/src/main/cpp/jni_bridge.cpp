// JNI bridge for com.example.feedbackkiller.audio.NativeEngine.
// One Engine per Java object, addressed by an opaque handle (no globals).
#include <jni.h>
#include <algorithm>
#include <array>
#include "fk/Engine.h"

namespace {
constexpr int kMaxFrames = 2048;

struct Handle {
  fk::Engine engine{fk::Config::androidLab()};
  // Fixed scratch buffers: no per-block heap allocation.
  std::array<float, kMaxFrames> input{}, output{};
  std::array<jshort, kMaxFrames> pcm{};
};
inline Handle* from(jlong h) { return reinterpret_cast<Handle*>(h); }
}  // namespace

#define FK(name) Java_com_example_feedbackkiller_audio_NativeEngine_##name

extern "C" {

JNIEXPORT jlong JNICALL FK(nativeCreate)(JNIEnv*, jclass) {
  return reinterpret_cast<jlong>(new Handle());
}

JNIEXPORT void JNICALL FK(nativeDestroy)(JNIEnv*, jclass, jlong h) { delete from(h); }

JNIEXPORT void JNICALL FK(nativeReset)(JNIEnv*, jclass, jlong h) {
  if (h) from(h)->engine.reset();
}

JNIEXPORT void JNICALL FK(nativeSetBypass)(JNIEnv*, jclass, jlong h, jboolean enabled) {
  if (h) from(h)->engine.setBypass(enabled == JNI_TRUE);
}

JNIEXPORT void JNICALL FK(nativeProcess)(JNIEnv* env, jclass, jlong h, jshortArray buffer, jint length) {
  if (!h || !buffer || length <= 0) return;
  Handle* s = from(h);
  const int count = std::min(static_cast<int>(env->GetArrayLength(buffer)), static_cast<int>(length));
  for (int offset = 0; offset < count; offset += kMaxFrames) {
    const int n = std::min(kMaxFrames, count - offset);
    env->GetShortArrayRegion(buffer, offset, n, s->pcm.data());
    if (env->ExceptionCheck()) return;
    for (int i = 0; i < n; i++) s->input[i] = s->pcm[i] / 32768.f;
    s->engine.process(s->input.data(), s->output.data(), n);
    for (int i = 0; i < n; i++)
      s->pcm[i] = static_cast<jshort>(std::clamp(s->output[i] * 32767.f, -32768.f, 32767.f));
    env->SetShortArrayRegion(buffer, offset, n, s->pcm.data());
    if (env->ExceptionCheck()) return;
  }
}

// Fills caller-provided float[6] (Hz, 0 = inactive); no allocation.
JNIEXPORT void JNICALL FK(nativeNotches)(JNIEnv* env, jclass, jlong h, jfloatArray out) {
  if (!h || !out || env->GetArrayLength(out) < fk::kMaxNotches) return;
  float hz[fk::kMaxNotches] = {};
  const auto notches = from(h)->engine.notches();
  for (int i = 0; i < fk::kMaxNotches; i++) hz[i] = notches[i].active ? notches[i].hz : 0.f;
  env->SetFloatArrayRegion(out, 0, fk::kMaxNotches, hz);
}

}  // extern "C"
