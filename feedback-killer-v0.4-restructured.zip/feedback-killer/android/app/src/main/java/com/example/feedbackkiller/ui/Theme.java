package com.example.feedbackkiller.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dark "console" palette plus small view-building helpers. */
final class Theme {
    static final int BG = 0xff080b0e, PANEL = 0xff151b21, CYAN = 0xff00d4c7, MUTED = 0xff81909d,
            WHITE = 0xffffffff, WARN_TEXT = 0xffffc36a, WARN_BG = 0xff292118, WARN_STROKE = 0xff644b2a,
            PANEL_STROKE = 0xff2a333b, TILE_STROKE = 0xff303943;

    private final Context ctx;
    Theme(Context ctx) { this.ctx = ctx; }

    int dp(int x) { return Math.round(ctx.getResources().getDisplayMetrics().density * x); }

    GradientDrawable box(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(18); d.setStroke(2, stroke);
        return d;
    }

    TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    LinearLayout column() {
        LinearLayout l = new LinearLayout(ctx);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout.LayoutParams params(int w, int h, int topMarginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topMarginDp);
        return p;
    }
}
