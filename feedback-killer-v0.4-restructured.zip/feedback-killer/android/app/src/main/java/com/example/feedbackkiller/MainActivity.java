package com.example.feedbackkiller;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.example.feedbackkiller.audio.AudioPipeline;
import com.example.feedbackkiller.audio.NativeEngine;
import com.example.feedbackkiller.ui.MainView;

/** Wiring only: permissions, lifecycle, and glue between the UI and the audio pipeline. */
public class MainActivity extends Activity implements MainView.Callbacks, AudioPipeline.Listener {
    private static final int REQ_RECORD_AUDIO = 1;
    private static final long UI_REFRESH_MS = 300;

    private NativeEngine engine;
    private AudioPipeline pipeline;
    private MainView view;
    private final float[] notchHz = new float[NativeEngine.NOTCH_COUNT];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            if (pipeline.isRunning()) {
                engine.readNotches(notchHz);
                view.setNotches(notchHz);
            }
            handler.postDelayed(this, UI_REFRESH_MS);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff080b0e);
        getWindow().setNavigationBarColor(0xff080b0e);
        engine = new NativeEngine();
        pipeline = new AudioPipeline(engine, this);
        view = new MainView(this, this);
        setContentView(view.root());
        handler.post(refresh);
    }

    // ---- MainView.Callbacks ----
    @Override public void onBypassChanged(boolean bypass) {
        pipeline.setBypass(bypass);
        view.setStatus(bypass ? "BYPASS ACTIVE" : "DSP ENABLED — LAB ONLY");
    }

    @Override public void onStartStopClicked() {
        if (pipeline.isRunning()) pipeline.stop();
        else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
        else pipeline.start();
    }

    // ---- AudioPipeline.Listener (main thread) ----
    @Override public void onStatus(String status) { view.setStatus(status); }
    @Override public void onRunningChanged(boolean running) { view.setRunning(running); }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] grants) {
        super.onRequestPermissionsResult(code, p, grants);
        if (code == REQ_RECORD_AUDIO && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED)
            pipeline.start();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(refresh);
        pipeline.stopAndJoin();
        engine.close();
        super.onDestroy();
    }
}
