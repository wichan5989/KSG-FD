package com.example.feedbackkiller.audio;

/** Thin Java wrapper over the native C++ engine (one instance = one native Engine). */
public final class NativeEngine implements AutoCloseable {
    static { System.loadLibrary("feedback_jni"); }

    public static final int NOTCH_COUNT = 6;

    private static native long nativeCreate();
    private static native void nativeDestroy(long handle);
    private static native void nativeReset(long handle);
    private static native void nativeSetBypass(long handle, boolean bypass);
    private static native void nativeProcess(long handle, short[] data, int frames);
    private static native void nativeNotches(long handle, float[] out);

    private volatile long handle = nativeCreate();

    public void reset()                    { long h = handle; if (h != 0) nativeReset(h); }
    public void setBypass(boolean bypass)  { long h = handle; if (h != 0) nativeSetBypass(h, bypass); }
    public void process(short[] pcm, int frames) { long h = handle; if (h != 0) nativeProcess(h, pcm, frames); }
    /** Fills {@code out} (length >= NOTCH_COUNT) with notch frequencies in Hz; 0 = inactive. */
    public void readNotches(float[] out)   { long h = handle; if (h != 0) nativeNotches(h, out); }

    /** Call only after the audio thread has stopped and UI polling is cancelled. */
    @Override public void close() {
        long h = handle; handle = 0;
        if (h != 0) nativeDestroy(h);
    }
}
