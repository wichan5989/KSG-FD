package com.example.feedbackkiller.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.util.Locale;

/** Builds the single dark console screen. Holds no audio logic: it only reports user intent. */
public final class MainView {
    public interface Callbacks {
        void onBypassChanged(boolean bypass);
        void onStartStopClicked();
    }

    public static final String START_LABEL = "START AUDIO TEST", STOP_LABEL = "STOP AUDIO TEST";
    public static final int NOTCH_COUNT = 6;

    private final ScrollView root;
    private final TextView status;
    private final Button startButton;
    private final TextView[] notchLabels = new TextView[NOTCH_COUNT];

    public MainView(Context ctx, Callbacks callbacks) {
        Theme t = new Theme(ctx);
        root = new ScrollView(ctx);
        root.setFillViewport(true);
        root.setBackgroundColor(Theme.BG);
        LinearLayout page = t.column();
        page.setPadding(t.dp(20), t.dp(24), t.dp(20), t.dp(24));
        root.addView(page);

        // Header
        page.addView(t.text("FK // LIVE DSP", 14, Theme.CYAN, true));
        page.addView(t.text("FEEDBACK KILLER", 27, Theme.WHITE, true));
        page.addView(t.text("MONO ENGINE  •  48 kHz  •  v0.4 LAB", 12, Theme.MUTED, false));

        // Safety warning
        TextView warning = t.text("LAB MODE — Headphones only. Do not connect to live PA.", 13, Theme.WARN_TEXT, true);
        warning.setPadding(t.dp(12), t.dp(14), t.dp(12), t.dp(14));
        warning.setBackground(t.box(Theme.WARN_BG, Theme.WARN_STROKE));
        page.addView(warning, t.params(-1, -2, 22));

        // Engine panel
        LinearLayout panel = t.column();
        panel.setPadding(t.dp(16), t.dp(18), t.dp(16), t.dp(18));
        panel.setBackground(t.box(Theme.PANEL, Theme.PANEL_STROKE));
        page.addView(panel, t.params(-1, -2, 16));
        panel.addView(t.text("AUDIO ENGINE", 12, Theme.CYAN, true));
        status = t.text("STOPPED  •  SAFE BYPASS", 16, Theme.WHITE, true);
        status.setPadding(0, t.dp(12), 0, t.dp(14));
        panel.addView(status);

        Switch bypass = new Switch(ctx);
        bypass.setText("BYPASS  /  DRY SIGNAL");
        bypass.setTextColor(Theme.WHITE);
        bypass.setChecked(true);
        bypass.setOnCheckedChangeListener((v, checked) -> callbacks.onBypassChanged(checked));
        panel.addView(bypass);

        startButton = new Button(ctx);
        startButton.setAllCaps(false);
        startButton.setText(START_LABEL);
        startButton.setTextColor(Theme.BG);
        startButton.setBackgroundTintList(ColorStateList.valueOf(Theme.CYAN));
        startButton.setOnClickListener((View v) -> callbacks.onStartStopClicked());
        panel.addView(startButton, t.params(-1, t.dp(54), 16));
        panel.addView(t.text("USB routing not yet verified • system default devices", 12, Theme.MUTED, false),
                t.params(-1, -2, 10));

        // Notch tiles (3 rows x 2)
        page.addView(t.text("ACTIVE NOTCH SLOTS", 13, Theme.CYAN, true), t.params(-1, -2, 26));
        for (int row = 0; row < 3; row++) {
            LinearLayout line = new LinearLayout(ctx);
            line.setOrientation(LinearLayout.HORIZONTAL);
            page.addView(line, t.params(-1, -2, 10));
            for (int c = 0; c < 2; c++) {
                int i = row * 2 + c;
                LinearLayout tile = t.column();
                tile.setPadding(t.dp(14), t.dp(13), t.dp(14), t.dp(13));
                tile.setBackground(t.box(Theme.PANEL, Theme.TILE_STROKE));
                LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, t.dp(84), 1);
                if (c == 1) tp.leftMargin = t.dp(10);
                line.addView(tile, tp);
                tile.addView(t.text("NOTCH 0" + (i + 1), 11, Theme.MUTED, true));
                notchLabels[i] = t.text("— Hz", 21, Theme.WHITE, true);
                tile.addView(notchLabels[i]);
            }
        }

        page.addView(t.text("Prototype: FFT + adaptive IIR notches. Detection is not validated against speech/music. "
                + "Use wired headphones at low volume.", 12, Theme.MUTED, false), t.params(-1, -2, 24));
    }

    public View root() { return root; }

    public void setStatus(String text) { status.setText(text); }

    public void setRunning(boolean running) { startButton.setText(running ? STOP_LABEL : START_LABEL); }

    /** @param hz one frequency per notch slot; values <= 0 mean "inactive". */
    public void setNotches(float[] hz) {
        for (int i = 0; i < NOTCH_COUNT; i++)
            notchLabels[i].setText(hz[i] > 0 ? String.format(Locale.US, "%.0f Hz", hz[i]) : "— Hz");
    }
}
