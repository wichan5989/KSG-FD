package com.example.feedbackkiller.audio;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;

/** Mic -> native DSP -> speaker loop running on its own thread. Callbacks arrive on the main thread. */
public final class AudioPipeline {
    public interface Listener {
        void onStatus(String status);
        void onRunningChanged(boolean running);
    }

    public static final String STATUS_STOPPED = "STOPPED  •  SAFE BYPASS";
    private static final int SAMPLE_RATE = 48000, CHUNK = 512;

    private final NativeEngine engine;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;
    private volatile boolean bypass = true;   // always start in safe bypass
    private Thread thread;

    public AudioPipeline(NativeEngine engine, Listener listener) {
        this.engine = engine;
        this.listener = listener;
    }

    public boolean isRunning() { return running; }
    public boolean isBypass()  { return bypass; }

    public void setBypass(boolean value) {
        bypass = value;
        engine.setBypass(value);
    }

    public synchronized void start() {
        if (running || (thread != null && thread.isAlive())) return;
        engine.reset();
        engine.setBypass(bypass);
        running = true;
        listener.onRunningChanged(true);
        thread = new Thread(this::loop, "fk-audio");
        thread.start();
    }

    public void stop() { running = false; }

    public void stopAndJoin() {
        running = false;
        Thread t = thread;
        if (t != null) {
            try { t.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    private void post(String status) { main.post(() -> listener.onStatus(status)); }

    private void loop() {
        AudioRecord record = null;
        AudioTrack track = null;
        String finalStatus = STATUS_STOPPED;
        try {
            int inMin = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int outMin = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (inMin <= 0 || outMin <= 0) { finalStatus = "48 kHz unsupported"; return; }

            record = new AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(inMin, CHUNK * 4));
            track = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(outMin, CHUNK * 4), AudioTrack.MODE_STREAM);
            if (record.getState() != AudioRecord.STATE_INITIALIZED || track.getState() != AudioTrack.STATE_INITIALIZED)
                throw new IllegalStateException("Audio device initialization failed");

            record.startRecording();
            track.play();
            short[] pcm = new short[CHUNK];
            post("RUNNING  •  " + (bypass ? "BYPASS" : "DSP"));

            while (running) {
                int n = record.read(pcm, 0, CHUNK, AudioRecord.READ_BLOCKING);
                if (n < 0) throw new IllegalStateException("AudioRecord read error: " + n);
                if (n == 0) continue;
                engine.process(pcm, n);
                int sent = 0;
                while (sent < n && running) {
                    int wrote = track.write(pcm, sent, n - sent, AudioTrack.WRITE_BLOCKING);
                    if (wrote <= 0) throw new IllegalStateException("AudioTrack write error: " + wrote);
                    sent += wrote;
                }
            }
        } catch (Exception e) {
            finalStatus = "AUDIO ERROR: " + e.getMessage();
        } finally {
            running = false;
            if (record != null) {
                try { record.stop(); } catch (Exception ignored) {}
                record.release();
            }
            if (track != null) {
                try { track.pause(); track.flush(); track.stop(); } catch (Exception ignored) {}
                track.release();
            }
            final String status = finalStatus;
            main.post(() -> { listener.onStatus(status); listener.onRunningChanged(false); });
        }
    }
}
