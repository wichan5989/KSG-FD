#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "fk/Engine.h"

#define CHECK(cond, msg) do { if(!(cond)) { std::fprintf(stderr, "FAIL: %s\n", msg); std::exit(1); } } while(0)

static constexpr int kSr = 48000;
static std::vector<float> sine(float hz, float amp, int n) {
  std::vector<float> v(n);
  for (int i = 0; i < n; i++) v[i] = amp * std::sin(2 * 3.141592653589793 * hz * i / kSr);
  return v;
}

static void testToneDetection() {
  fk::Engine e;
  auto in = sine(1000.f, .25f, kSr * 2);
  std::vector<float> out(in.size());
  e.process(in.data(), out.data(), in.size());
  bool found = false;
  for (auto n : e.notches()) if (n.active && std::abs(n.hz - 1000) < 30) found = true;
  CHECK(found, "expected a notch near 1 kHz");
}

static void testSilenceAndFinite() {
  fk::Engine e;
  std::vector<float> in(kSr * 2, 0.f), out(in.size());
  e.process(in.data(), out.data(), in.size());
  for (float v : out) CHECK(std::isfinite(v) && std::abs(v) < 1e-6f, "silence must stay silent/finite");
  for (auto n : e.notches()) CHECK(!n.active, "no notch expected on silence");
}

static void testBypassIsDry() {
  fk::Engine e; e.setBypass(true);
  auto in = sine(1000.f, .25f, kSr);
  std::vector<float> out(in.size());
  e.process(in.data(), out.data(), in.size());
  for (size_t i = 0; i < in.size(); i++) CHECK(out[i] == in[i], "bypass must pass signal unchanged");
}

static void testResetClearsNotches() {
  fk::Engine e;
  auto in = sine(1000.f, .25f, kSr * 2);
  std::vector<float> out(in.size());
  e.process(in.data(), out.data(), in.size());
  e.reset();
  for (auto n : e.notches()) CHECK(!n.active, "reset must clear notches");
}

static void testOutputClamped() {
  fk::Engine e;
  std::vector<float> in(4096, 3.f), out(in.size());
  e.process(in.data(), out.data(), in.size());
  for (float v : out) CHECK(std::abs(v) <= 1.f, "output must be clamped to [-1,1]");
}

int main() {
  testToneDetection(); testSilenceAndFinite(); testBypassIsDry();
  testResetClearsNotches(); testOutputClamped();
  std::puts("PASS: tone detection, silence, bypass, reset, clamping");
}
