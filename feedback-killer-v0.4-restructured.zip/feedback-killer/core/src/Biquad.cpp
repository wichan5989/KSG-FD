#include "fk/Biquad.h"
#include <algorithm>
#include <cmath>
#include "fk/Math.h"
namespace fk {
float Biquad::process(float x) {
  const float y = b0 * x + z1;
  z1 = b1 * x - a1 * y + z2;
  z2 = b2 * x - a2 * y;
  return y;
}
void Biquad::setNotch(float sr, float hz, float q) {
  const float w = 2.f * kPi * hz / sr, alpha = std::sin(w) / (2.f * std::max(q, 1.f));
  const float inv = 1.f / (1.f + alpha);
  b0 = inv; b1 = -2.f * std::cos(w) * inv; b2 = inv;
  a1 = b1; a2 = (1.f - alpha) * inv;
  z1 = z2 = 0.f;
}
}  // namespace fk
