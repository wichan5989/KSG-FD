#include "fk/Engine.h"
#include <algorithm>
#include <cmath>
#include "fk/Fft.h"
namespace fk {

Engine::Engine(Config cfg) : cfg_(cfg) {
  for (int i = 0; i < N; i++) window_[i] = .5f - .5f * std::cos(2.f * kPi * i / (N - 1));
  reset();
}

void Engine::reset() {
  ring_.fill(0); spectrum_.fill(0); previous_.fill(0); smoothed_.fill(0);
  persistence_.fill(0); slots_ = {}; position_ = total_ = 0;
  publishNotches();
}

void Engine::publishNotches() {
  for (int i = 0; i < kMaxNotches; i++) {
    const bool active = slots_[i].occupied && slots_[i].target > 0.f;
    published_[i].store(active ? slots_[i].hz : 0.f, std::memory_order_relaxed);
  }
}

void Engine::analyze() {
  for (int i = 0; i < N; i++) fft_[i] = {ring_[(position_ + i) % N] * window_[i], 0.f};
  fft(fft_);
  for (int k = 0; k <= N / 2; k++) {
    spectrum_[k] = std::abs(fft_[k]);
    smoothed_[k] = .85f * smoothed_[k] + .15f * spectrum_[k];
  }
  const int lo = std::max(6, int(std::ceil(cfg_.minHz * N / cfg_.sampleRate)));
  const int hi = std::min(N / 2 - 6, int(std::floor(cfg_.maxHz * N / cfg_.sampleRate)));
  const float ratio = std::pow(10.f, cfg_.thresholdDb / 20.f);
  const int maxMiss = std::max(1, int(cfg_.releaseSeconds * cfg_.sampleRate / Hop));

  // 1) Keep/release active notches by checking the unfiltered input spectrum.
  for (auto& slot : slots_) if (slot.occupied) {
    const int k = std::clamp(int(std::round(slot.hz * N / cfg_.sampleRate)), lo, hi);
    const float peak = std::max({spectrum_[k - 1], spectrum_[k], spectrum_[k + 1]});
    float neighbor = 0.f;
    for (int d = 3; d <= 5; d++) neighbor += spectrum_[k - d] + spectrum_[k + d];
    neighbor /= 6.f;
    if (peak > std::max(.01f, neighbor * ratio * .55f)) slot.missed = 0;
    else if (++slot.missed > maxMiss) slot.target = 0.f;
  }

  // 2) Detect new persistent, prominent peaks and allocate notch slots.
  for (int k = lo; k <= hi; k++) {
    float nearby = 0.f;
    for (int d = 3; d <= 5; d++) nearby += spectrum_[k - d] + spectrum_[k + d];
    nearby /= 6.f;
    const bool peak = spectrum_[k] > spectrum_[k - 1] && spectrum_[k] >= spectrum_[k + 1];
    const bool prominent = peak && spectrum_[k] > std::max(.01f, nearby * ratio);
    const float growth = 20.f * std::log10((spectrum_[k] + 1e-6f) / (previous_[k] + 1e-6f));
    const bool growing = !cfg_.requireGrowth || growth >= cfg_.growthDb;
    persistence_[k] = (prominent && growing) ? std::min(20, persistence_[k] + 1)
                                             : std::max(0, persistence_[k] - 1);
    if (persistence_[k] < cfg_.persistenceFrames) continue;
    if (spectrum_[k] < 0.1f) continue;  // reject very low-energy peaks

    // Parabolic interpolation of log magnitude -> sub-bin frequency.
    const float l = std::log(spectrum_[k - 1] + 1e-6f), m = std::log(spectrum_[k] + 1e-6f),
                r = std::log(spectrum_[k + 1] + 1e-6f);
    const float denom = l - 2.f * m + r;
    const float delta = std::abs(denom) > 1e-6f ? std::clamp(.5f * (l - r) / denom, -.5f, .5f) : 0.f;
    const float hz = (k + delta) * cfg_.sampleRate / N;

    bool covered = false;
    for (const auto& slot : slots_)
      if (slot.occupied && std::abs(slot.hz - hz) < std::max(30.f, hz / 30.f)) { covered = true; break; }
    if (covered) continue;
    for (auto& slot : slots_) if (!slot.occupied) {
      slot = {}; slot.occupied = true; slot.hz = hz; slot.target = 1.f;
      slot.filter.setNotch(cfg_.sampleRate, hz, cfg_.notchQ);
      break;
    }
  }

  // 3) Slow baseline so growth is measured across successive hops.
  for (int k = 0; k <= N / 2; k++) previous_[k] = .96f * previous_[k] + .04f * spectrum_[k];
  publishNotches();
}

void Engine::process(const float* in, float* out, std::size_t frames) {
  const float attack = 1.f / std::max(1.f, cfg_.attackSeconds * cfg_.sampleRate);
  const float fade = 1.f / std::max(1.f, cfg_.fadeSeconds * cfg_.sampleRate);
  const bool bypass = bypass_.load(std::memory_order_relaxed);
  for (std::size_t i = 0; i < frames; i++) {
    const float x = in[i];
    ring_[position_] = x; position_ = (position_ + 1) % N; ++total_;
    float y = x;
    for (auto& slot : slots_) if (slot.occupied) {
      const float step = slot.target > slot.wet ? attack : fade;
      slot.wet += std::clamp(slot.target - slot.wet, -step, step);
      const float filtered = slot.filter.process(y);
      y += (filtered - y) * slot.wet;
      if (slot.target == 0.f && slot.wet <= 0.f) slot = {};
    }
    out[i] = bypass ? x : std::clamp(y, -1.f, 1.f);
    if (total_ >= N && (total_ - N) % Hop == 0) analyze();
  }
}

std::array<NotchInfo, kMaxNotches> Engine::notches() const {
  std::array<NotchInfo, kMaxNotches> result{};
  for (int i = 0; i < kMaxNotches; i++) {
    const float hz = published_[i].load(std::memory_order_relaxed);
    result[i] = {hz, hz > 0.f};
  }
  return result;
}
}  // namespace fk
