add_library(feedback_core STATIC
  src/Engine.cpp
  src/Biquad.cpp)
target_include_directories(feedback_core PUBLIC include)
target_compile_features(feedback_core PUBLIC cxx_std_17)
set_target_properties(feedback_core PROPERTIES POSITION_INDEPENDENT_CODE ON)
