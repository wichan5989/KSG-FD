#pragma once
namespace fk {
struct Config {
  float sampleRate = 48000.f, thresholdDb = 13.f, growthDb = 3.f;
  int persistenceFrames = 4;
  float minHz = 150.f, maxHz = 8000.f, notchQ = 25.f;
  float releaseSeconds = 3.f, attackSeconds = .025f, fadeSeconds = .06f;
  bool requireGrowth = false;  // enable after calibration; steady-tone bench tests use false

  // Preset used by the Android app (stricter than the desktop defaults).
  static Config androidLab() {
    Config c;
    c.thresholdDb = 17.f;
    c.persistenceFrames = 7;
    c.releaseSeconds = 3.f;
    c.notchQ = 30.f;
    return c;
  }
};
}  // namespace fk
