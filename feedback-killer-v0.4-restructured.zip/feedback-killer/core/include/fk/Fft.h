#pragma once
#include <array>
#include <complex>
#include <cstddef>
#include <utility>
#include "fk/Math.h"
namespace fk {
// In-place radix-2 FFT. N must be a power of two.
template <std::size_t N>
void fft(std::array<std::complex<float>, N>& a) {
  constexpr int n = static_cast<int>(N);
  for (int i = 1, j = 0; i < n; i++) {
    int bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) std::swap(a[i], a[j]);
  }
  for (int len = 2; len <= n; len <<= 1) {
    const float ang = -2.f * kPi / len;
    const std::complex<float> step(std::cos(ang), std::sin(ang));
    for (int i = 0; i < n; i += len) {
      std::complex<float> w(1, 0);
      for (int j = 0; j < len / 2; j++) {
        const auto u = a[i + j], v = a[i + j + len / 2] * w;
        a[i + j] = u + v;
        a[i + j + len / 2] = u - v;
        w *= step;
      }
    }
  }
}
}  // namespace fk
