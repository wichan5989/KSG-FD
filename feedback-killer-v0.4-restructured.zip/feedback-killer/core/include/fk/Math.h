#pragma once
namespace fk {
constexpr float kPi = 3.14159265358979323846f;
}
