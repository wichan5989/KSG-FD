#pragma once
#include <array>
#include <atomic>
#include <complex>
#include <cstddef>
#include "fk/Biquad.h"
#include "fk/Config.h"

namespace fk {
constexpr int kMaxNotches = 6;

struct NotchInfo {
  float hz = 0.f;
  bool active = false;
};

// Mono feedback suppressor: FFT peak detection + adaptive IIR notches.
//
// Threading: process()/reset() belong to the audio thread. setBypass() and
// notches() are safe to call from any other thread (lock-free atomics).
class Engine {
 public:
  explicit Engine(Config cfg = {});
  void process(const float* in, float* out, std::size_t frames);
  void reset();  // clears DSP state; does not change bypass
  std::array<NotchInfo, kMaxNotches> notches() const;
  void setBypass(bool b) { bypass_.store(b, std::memory_order_relaxed); }

 private:
  static constexpr int N = 2048, Hop = 512;
  struct Slot {
    Biquad filter;
    float hz = 0, wet = 0, target = 0;
    int missed = 0;
    bool occupied = false;
  };

  void analyze();
  void publishNotches();

  Config cfg_;
  std::array<float, N> ring_{}, window_{};
  std::array<std::complex<float>, N> fft_{};
  std::array<float, N / 2 + 1> spectrum_{}, previous_{}, smoothed_{};
  std::array<int, N / 2 + 1> persistence_{};
  std::array<Slot, kMaxNotches> slots_{};
  std::size_t position_ = 0, total_ = 0;
  std::atomic<bool> bypass_{false};
  // Snapshot for other threads: 0 Hz = inactive.
  std::array<std::atomic<float>, kMaxNotches> published_{};
};
}  // namespace fk
