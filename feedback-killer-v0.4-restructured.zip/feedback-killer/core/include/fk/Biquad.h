#pragma once
namespace fk {
// Direct-form II transposed biquad configured as a notch filter.
struct Biquad {
  float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
  float process(float x);
  void setNotch(float sampleRate, float hz, float q);
};
}  // namespace fk
